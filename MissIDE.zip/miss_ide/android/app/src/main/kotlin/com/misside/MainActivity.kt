// android/app/src/main/kotlin/com/misside/MainActivity.kt
package com.misside

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.misside/jadx"
    
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "decompile" -> {
                    val apkPath = call.argument<String>("apkPath")
                    val outputDir = call.argument<String>("outputDir")
                    
                    if (apkPath != null && outputDir != null) {
                        // TODO: 实现Jadx反编译逻辑
                        result.success(mapOf(
                            "success" to true,
                            "outputDir" to outputDir
                        ))
                    } else {
                        result.error("INVALID_ARGS", "Missing required arguments", null)
                    }
                }
                "getVersion" -> {
                    result.success("1.0.0")
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }
}
